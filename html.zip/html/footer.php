  
    <div class="container">
    
    <img src="images/bg2.png" alt="#" style="width:100%;">
   	<div class="row">
        <div class="col-lg-12 col-md-12  col-sm-12 col-xs-12 footerblock">
        <span>Copyright &copy; 2015-2016 Voortal. All Rights Reserved.</span>
        
   <a href="javascript:void(0)">Privacy Policy</a>
        </div>
 
   </div>     
        
   
        </div>
    

        
        

</body>
</html>
