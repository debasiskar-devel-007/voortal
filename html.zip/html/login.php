<?php include('top.php') ?>
     
       <div class="container-fluid">
   	<div class="row">
    
        
    
    <div class="col-lg-12 col-md-12  col-sm-12 col-xs-12 innerlogin">
    
        
         <div class="container">
          
         
          <div class="login_block "> <span><a href="javascript:void(0)">Login</a> / <a href="javascript:void(0)">Signup</a></span></div>
          
          
          
          <div class="clearfix"></div>
          
   </div>  
            </div>  
             <div class="clearfix"></div>
               <a href="index.php"> <img src="images/logo.png" alt="#" class="mobilelogo"></a>
               
        </div>
        
        </div> 
         
         
        
        <div class="container">
        	<div class="row">
        <div class="col-lg-12 col-md-12  col-sm-12 col-xs-12 loginwrapper">

       <div class="loginbox"> 
       
        <div class="loginbox_formcontain"> 
    <h2>Login to Your Account</h2>
        <div class="popupdevider"></div>
        
        
        <img src="images/lockicon.png" alt="#" style="display:block; margin:25px auto;">
        
        <form>
        <input type="text" placeholder="Email">
        
        <input type="password" placeholder="Password">
        
        <input type="submit" value="Login" class="subbtn">
        
        <div class="Forgotlink">Forgot Password? <a href="#">Click Here</a> | Not a member yet <a href="#">Sign Up</a></div>
        
        
       <div class="Securelogin"> <a href="#">Secure Login</a></div>
        
        
        </form>
    </div>
    </div>
    </div>
     </div>
      </div>
    
<?php include('footer.php') ?>

